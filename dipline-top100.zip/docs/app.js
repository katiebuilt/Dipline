"use strict";
/* Dipline front-end: Finviz-style screener / map / signals / alerts / settings for the Top 100 US stocks. */
const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const LS = {
  get(k, d) { try { const v = localStorage.getItem("dl_" + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem("dl_" + k, JSON.stringify(v)); } catch {} }
};
const S = { sig: null, charts: null, alerts: [], cfg: null, view: LS.get("view", "overview"), sort: { k: "no", d: 1 },
  f: { st: "ALL", sector: "", q: "", fav: false }, favs: LS.get("favs", []), range: 100, mapMode: "day" };

/* ---------- formatting ---------- */
const n2 = (x, d = 2) => x == null ? "–" : Number(x).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
const pct = (x, d = 2) => x == null ? "–" : `<span class="${x > 0 ? "up" : x < 0 ? "dn" : "mut"}">${x > 0 ? "+" : ""}${n2(x, d)}%</span>`;
const cap = x => !x ? "–" : x >= 1e12 ? (x / 1e12).toFixed(2) + "T" : (x / 1e9).toFixed(0) + "B";
const ago = ts => { const m = Math.round((Date.now() / 1000 - ts) / 60); return m < 1 ? "just now" : m < 60 ? m + "m ago" : m < 1440 ? Math.round(m / 60) + "h ago" : Math.round(m / 1440) + "d ago"; };
const scCol = s => s >= 70 ? "#2ecc71" : s >= 50 ? "#f5a623" : s >= 40 ? "#4aa3ff" : "#3a4654";
const badge = st => `<span class="badge ${st}">${st === "NONE" ? "–" : st}</span>`;
const scBadge = s => `<span class="sc" style="background:${scCol(s)}22;color:${scCol(s)}">${s}</span>`;
function spark(a, w = 64, h = 20) {
  if (!a || a.length < 2) return "";
  const mn = Math.min(...a), mx = Math.max(...a), r = mx - mn || 1;
  const pts = a.map((v, i) => `${(i / (a.length - 1) * w).toFixed(1)},${(h - (v - mn) / r * (h - 2) - 1).toFixed(1)}`).join(" ");
  return `<svg class="sp" width="${w}" height="${h}"><polyline points="${pts}" fill="none" stroke="${a.at(-1) >= a[0] ? "#2ecc71" : "#ef5350"}" stroke-width="1.5"/></svg>`;
}

/* ---------- data ---------- */
async function getJSON(u) { const r = await fetch(u + (u.includes("?") ? "&" : "?") + "t=" + Date.now(), { cache: "no-store" }); if (!r.ok) throw new Error(u + " " + r.status); return r.json(); }
async function loadAll(initial) {
  try {
    const [sig, cfg, alerts] = await Promise.all([getJSON("data/signals.json"), getJSON("config.json").catch(() => ({ enabled: true })), getJSON("data/alerts.json").catch(() => [])]);
    const same = S.sig && sig.meta.generated_at === S.sig.meta.generated_at && JSON.stringify(cfg) === JSON.stringify(S.cfg);
    S.sig = sig; S.cfg = cfg; S.alerts = alerts; S.err = null;
    if (same && !initial) return;
    if (!initial) S.charts = null;
  } catch (e) { S.err = e.message; }
  render();
}
async function ensureCharts() { if (!S.charts) { try { S.charts = await getJSON("data/charts.json"); } catch { S.charts = {}; } } return S.charts; }

/* ---------- GitHub-backed on/off switch ---------- */
const GH = { repo: () => LS.get("repo", ""), tok: () => LS.get("tok", "") };
const ghFetch = (path, o = {}) => fetch(`https://api.github.com/repos/${GH.repo()}/contents/${path}`, { ...o, headers: { Authorization: `Bearer ${GH.tok()}`, Accept: "application/vnd.github+json", ...(o.headers || {}) } });
const b64d = s => decodeURIComponent(escape(atob(s.replace(/\n/g, ""))));
const b64e = s => btoa(unescape(encodeURIComponent(s)));
async function readCfg() { const r = await ghFetch("docs/config.json"); if (!r.ok) throw new Error("GitHub " + r.status + " - check repo name & token"); const j = await r.json(); return { cfg: JSON.parse(b64d(j.content)), sha: j.sha }; }
async function patchCfg(patch) {
  const { cfg, sha } = await readCfg(); const next = { ...cfg, ...patch };
  const r = await ghFetch("docs/config.json", { method: "PUT", body: JSON.stringify({ message: "Dipline settings: " + JSON.stringify(patch), content: b64e(JSON.stringify(next, null, 2) + "\n"), sha }) });
  if (!r.ok) throw new Error("GitHub " + r.status + " - token needs 'Contents: read & write'");
  S.cfg = next; return next;
}

/* ---------- header ---------- */
function renderHeader() {
  const el = $("#status"), s = S.sig;
  if (!s) { el.innerHTML = '<span class="dot"></span>loading'; return; }
  const on = S.cfg?.enabled !== false, age = (Date.now() / 1000 - s.meta.generated_at) / 60;
  const stale = on && s.meta.market_open && age > 90;
  el.innerHTML = `<span class="dot ${!on ? "off" : stale ? "stale" : "on"}"></span>${on ? "AUTO ON" : "PAUSED"} · ${ago(s.meta.generated_at)}`;
  el.onclick = () => location.hash = "#/settings";
  $("#idx").innerHTML = (s.market || []).map(m => `<div class="ix"><span>${esc(m.name)}</span><b>${n2(m.price)}</b><em>${pct(m.chg1)}</em></div>`).join("");
}

/* ---------- screener ---------- */
const VIEWS = {
  overview: [["Ticker", "t", "tk"], ["Price", "p"], ["Change", "c1"], ["Signal", "st"], ["Score", "sc"], ["Rel Vol", "rv"], ["Mkt Cap", "mc"], ["Company", "n", "nm"], ["Sector", "s", "nm"]],
  technical: [["Ticker", "t", "tk"], ["RSI", "rsi"], ["5D", "c5"], ["20D", "c20"], ["vs 50D", "d50"], ["vs 200D", "d200"], ["From 52W Hi", "fh"], ["Trend", "sp"], ["Score", "sc"]],
  levels: [["Ticker", "t", "tk"], ["Signal", "st"], ["Score", "sc"], ["Key Level", "lv"], ["Dist", "ld"], ["Stop", "stop"], ["Target", "target"], ["R:R", "rr"], ["Level Type", "ll", "hl"]]
};
const val = (r, k) => k === "stop" ? r.plan?.stop : k === "target" ? r.plan?.target : k === "rr" ? r.plan?.rr : r[k];
function cell(r, k) {
  switch (k) {
    case "t": return `${r.t}`;
    case "n": case "s": case "ll": return esc(r[k] ?? "–");
    case "mc": return cap(r.mc);
    case "p": return n2(r.p);
    case "c1": case "c5": case "c20": case "d50": case "d200": case "fh": return pct(r[k], k === "c1" ? 2 : 1);
    case "ld": return r.ld == null ? "–" : `${n2(r.ld, 1)}%`;
    case "rv": return `<span class="${r.rv >= 1.5 ? "up" : ""}">${n2(r.rv)}x</span>`;
    case "rsi": return `<span class="${r.rsi <= 30 ? "up" : r.rsi >= 70 ? "dn" : ""}">${r.rsi}</span>`;
    case "st": return badge(r.st);
    case "sc": return scBadge(r.sc);
    case "sp": return spark(r.sp);
    case "lv": return r.lv == null ? "–" : n2(r.lv);
    case "stop": case "target": return r.plan ? n2(val(r, k)) : "–";
    case "rr": return r.plan ? n2(r.plan.rr, 1) : "–";
  }
}
function filtered() {
  const f = S.f, q = f.q.trim().toLowerCase();
  let rows = S.sig.rows.filter(r => (f.st === "ALL" || r.st === f.st) && (!f.sector || r.s === f.sector) && (!f.fav || S.favs.includes(r.t)) &&
    (!q || r.t.toLowerCase().includes(q) || r.n.toLowerCase().includes(q)));
  const { k, d } = S.sort;
  rows.sort((a, b) => { let x = val(a, k), y = val(b, k); if (k === "st") { const o = { BUY: 0, SETUP: 1, WATCH: 2, NONE: 3 }; x = o[a.st]; y = o[b.st]; } if (x == null) return 1; if (y == null) return -1; return (typeof x === "string" ? x.localeCompare(y) : x - y) * d; });
  return rows;
}
function viewScreener() {
  const m = S.sig.meta.counts, sectors = [...new Set(S.sig.rows.map(r => r.s))].sort();
  const rows = filtered(), cols = VIEWS[S.view];
  return `${S.sig.meta.demo ? '<div class="demo">DEMO DATA · not real prices</div>' : ""}
  <div class="sum">${["BUY", "SETUP", "WATCH"].map(k => `<button class="${k} ${S.f.st === k ? "on" : ""}" data-st="${k}"><b>${m[k]}</b><span>${k}</span></button>`).join("")}</div>
  <div class="bar"><input id="q" type="search" placeholder="Search ticker or company" value="${esc(S.f.q)}" autocomplete="off">
    <select id="sec"><option value="">All sectors</option>${sectors.map(s => `<option ${S.f.sector === s ? "selected" : ""}>${esc(s)}</option>`).join("")}</select></div>
  <div class="chips">${["overview", "technical", "levels"].map(v => `<span class="chip ${S.view === v ? "on" : ""}" data-view="${v}">${v[0].toUpperCase() + v.slice(1)}</span>`).join("")}
    <span class="chip ${S.f.fav ? "on" : ""}" id="favf">★ My list (${S.favs.length})</span><span class="chip ${S.f.st === "ALL" ? "" : "on"}" data-st="ALL">Clear signal filter</span></div>
  <div class="tw"><table><thead><tr>${cols.map(([h, k, c]) => `<th class="${c === "tk" ? "tk" : ""} ${["n", "s", "ll"].includes(k) || c === "tk" ? "l" : ""}" data-sort="${k}">${h}${S.sort.k === k ? (S.sort.d > 0 ? " ▲" : " ▼") : ""}</th>`).join("")}</tr></thead>
  <tbody>${rows.map(r => `<tr data-t="${r.t}">${cols.map(([h, k, c]) => k === "t" ? `<td class="tk"><span class="st ${S.favs.includes(r.t) ? "on" : ""}" data-fav="${r.t}">★</span>${r.t}</td>` : `<td class="${c || ""}">${cell(r, k)}</td>`).join("")}</tr>`).join("") || `<tr><td class="l" colspan="9" style="padding:30px">No matches.</td></tr>`}</tbody></table></div>
  <div class="disc">${rows.length} of ${S.sig.rows.length} stocks · Tap a row for the full buy plan · Not financial advice</div>`;
}
function bindScreener() {
  const v = $("#view");
  v.querySelectorAll("[data-st]").forEach(b => b.onclick = () => { S.f.st = S.f.st === b.dataset.st ? "ALL" : b.dataset.st; render(); });
  v.querySelectorAll("[data-view]").forEach(b => b.onclick = () => { S.view = b.dataset.view; LS.set("view", S.view); render(); });
  v.querySelectorAll("[data-sort]").forEach(b => b.onclick = () => { const k = b.dataset.sort; S.sort = S.sort.k === k ? { k, d: -S.sort.d } : { k, d: ["t", "n", "s", "no", "ll"].includes(k) ? 1 : -1 }; render(); });
  $("#favf").onclick = () => { S.f.fav = !S.f.fav; render(); };
  $("#sec").onchange = e => { S.f.sector = e.target.value; render(); };
  $("#q").oninput = e => { S.f.q = e.target.value; const p = e.target.selectionStart; render(); const q = $("#q"); q.focus(); q.setSelectionRange(p, p); };
  v.querySelectorAll("tr[data-t]").forEach(tr => tr.onclick = e => {
    const fav = e.target.closest("[data-fav]");
    if (fav) { toggleFav(fav.dataset.fav); return; }
    location.hash = "#/t/" + tr.dataset.t;
  });
}
function toggleFav(t) { S.favs = S.favs.includes(t) ? S.favs.filter(x => x !== t) : [...S.favs, t]; LS.set("favs", S.favs); render(); }

/* ---------- signals (action list) ---------- */
function planBox(p) { return p ? `<div class="plan"><div><span>ENTRY</span><b>${n2(p.entry_lo)}–${n2(p.entry_hi)}</b></div><div><span>STOP</span><b class="dn">${n2(p.stop)}</b></div><div><span>TARGET</span><b class="up">${n2(p.target)}</b></div><div><span>R:R</span><b>${n2(p.rr, 1)}</b></div></div>` : ""; }
function viewSignals() {
  const groups = [["BUY", "Buy zone · reversal confirmed at a key level"], ["SETUP", "At the key level · waiting for confirmation"], ["WATCH", "Heading to a key level · plan your entry"]];
  const body = groups.map(([st, title]) => {
    const rs = S.sig.rows.filter(r => r.st === st).sort((a, b) => b.sc - a.sc);
    return `<h3 class="sec">${st} · ${rs.length} <span style="text-transform:none;letter-spacing:0">— ${title}</span></h3>` +
      (rs.length ? `<div class="cards">${rs.map(r => `<div class="card ${st}" data-t="${r.t}"><div class="r1"><div><span class="tkr">${r.t}</span><span class="co">${esc(r.n)}</span></div><div>${scBadge(r.sc)}</div></div>
      <div class="mut" style="font-size:12px">$${n2(r.p)} ${pct(r.c1)} · RSI ${r.rsi} · ${r.rv}x vol${r.prov ? " · <span style='color:var(--acc)'>intraday</span>" : ""}</div>
      <p>${esc(r.hl)}</p>${planBox(r.plan)}</div>`).join("")}</div>` : `<div class="empty" style="padding:16px">None right now.</div>`);
  }).join("");
  return (S.sig.meta.demo ? '<div class="demo">DEMO DATA · not real prices</div>' : "") + body + '<div class="disc">Signals are rules-based screens, not advice. Always size positions and use your own stop.</div>';
}

/* ---------- heat map ---------- */
function squarify(items, x, y, w, h) {
  const tot = items.reduce((a, b) => a + b.v, 0); if (!tot) return [];
  const k = w * h / tot, it = items.map(i => ({ ...i, a: i.v * k })), res = [];
  let row = [];
  const sum = r => r.reduce((a, b) => a + b.a, 0);
  const worst = (r, side) => { const s = sum(r), mx = Math.max(...r.map(i => i.a)), mn = Math.min(...r.map(i => i.a)); return Math.max(side * side * mx / (s * s), s * s / (side * side * mn)); };
  const place = r => {
    const s = sum(r);
    if (w >= h) { const cw = s / h; let cy = y; r.forEach(i => { const ih = i.a / cw; res.push({ ...i, x, y: cy, w: cw, h: ih }); cy += ih; }); x += cw; w -= cw; }
    else { const rh = s / w; let cx = x; r.forEach(i => { const iw = i.a / rh; res.push({ ...i, x: cx, y, w: iw, h: rh }); cx += iw; }); y += rh; h -= rh; }
  };
  let i = 0;
  while (i < it.length) { const side = Math.min(w, h); if (!row.length || worst([...row, it[i]], side) <= worst(row, side)) { row.push(it[i]); i++; } else { place(row); row = []; } }
  if (row.length) place(row);
  return res;
}
const dayCol = c => { const t = Math.max(-1, Math.min(1, (c ?? 0) / 3)); const g = [39, 174, 96], r = [192, 57, 43], m = [47, 53, 66]; const e = t >= 0 ? g : r, a = Math.abs(t); return `rgb(${m.map((v, i) => Math.round(v + (e[i] - v) * a)).join(",")})`; };
const sigCol = r => ({ BUY: "#1e9e57", SETUP: "#b5780f", WATCH: "#2a6db3", NONE: "#262e3a" }[r.st]);
function viewMap() {
  return `${S.sig.meta.demo ? '<div class="demo">DEMO DATA · not real prices</div>' : ""}<div class="chips" style="padding-top:6px"><span class="chip ${S.mapMode === "day" ? "on" : ""}" data-mm="day">Color: Day %</span><span class="chip ${S.mapMode === "sig" ? "on" : ""}" data-mm="sig">Color: Buy signal</span></div>
  <div class="mapw" id="mapw"></div>
  <div class="legend">${S.mapMode === "day" ? '<span class="dn">■ −3%</span><span>■ 0</span><span class="up">■ +3%</span>' : '<span style="color:#1e9e57">■ BUY</span><span style="color:#b5780f">■ SETUP</span><span style="color:#2a6db3">■ WATCH</span><span>■ none</span>'}<span>Size = market cap · outlines mark live signals</span></div>`;
}
function drawMap() {
  const box = $("#mapw"); if (!box) return;
  const W = box.clientWidth || window.innerWidth - 16, H = Math.round(Math.min(window.innerHeight * 0.68, W * 1.5)); box.style.height = H + "px";
  const bySec = {}; S.sig.rows.forEach(r => (bySec[r.s] ||= []).push(r));
  const secs = Object.entries(bySec).map(([s, rs]) => ({ s, rs, v: rs.reduce((a, r) => a + Math.pow(r.mc || 1e10, 0.75), 0) })).sort((a, b) => b.v - a.v);
  let html = "";
  squarify(secs, 0, 0, W, H).forEach(sc => {
    const hd = sc.h > 40 && sc.w > 60 ? 13 : 0;
    html += `<div class="sector" style="left:${sc.x}px;top:${sc.y}px;max-width:${sc.w}px">${esc(sc.s)}</div>`;
    squarify(sc.rs.map(r => ({ r, v: Math.pow(r.mc || 1e10, 0.75) })).sort((a, b) => b.v - a.v), sc.x, sc.y + hd, sc.w, sc.h - hd).forEach(t => {
      const r = t.r, fs = Math.max(7, Math.min(15, Math.sqrt(t.w * t.h) / 4.2)), small = t.w < 30 || t.h < 22;
      html += `<div class="tile ${r.st}" data-t="${r.t}" style="left:${t.x}px;top:${t.y}px;width:${t.w}px;height:${t.h}px;background:${S.mapMode === "day" ? dayCol(r.c1) : sigCol(r)};font-size:${fs}px">${small ? "" : `<b>${r.t}</b>${t.h > 34 ? `<i>${r.c1 > 0 ? "+" : ""}${n2(r.c1)}%</i>` : ""}`}</div>`;
    });
  });
  box.innerHTML = html;
  box.querySelectorAll(".tile").forEach(t => t.onclick = () => location.hash = "#/t/" + t.dataset.t);
}

/* ---------- alerts ---------- */
function viewAlerts() {
  const a = S.alerts;
  return (S.sig?.meta.demo ? '<div class="demo">DEMO DATA · not real prices</div>' : "") + `<h3 class="sec">Recent alerts</h3>` + (a.length ? `<div class="cards">${a.slice(0, 60).map(x => `<div class="card ${x.st}" data-t="${x.t}"><div class="r1"><div><span class="tkr">${x.t}</span> ${badge(x.st)}</div><span class="mut" style="font-size:12px">${ago(x.ts)}</span></div><p style="margin-bottom:0">${esc(x.hl)}</p><div class="mut" style="font-size:12px;margin-top:4px">$${n2(x.p)} · score ${x.sc}</div></div>`).join("")}</div>` : '<div class="empty">No alerts yet.<br>They appear here (and on your lock screen) when a stock reaches WATCH, SETUP or BUY.</div>');
}

/* ---------- settings ---------- */
function viewSettings() {
  const cfg = S.cfg || {}, linked = GH.repo() && GH.tok(), on = cfg.enabled !== false, topic = LS.get("topic", "");
  const al = cfg.alert_on || ["WATCH", "SETUP", "BUY"];
  return `<h3 class="sec">Autonomous scanner</h3>
  <div class="set"><div class="row"><div><h4 style="margin:0">Scanner ${on ? "ON" : "OFF"}</h4><p style="margin:2px 0 0">Scans the Top 100 every 30 min during market hours and sends alerts.</p></div><button class="sw ${on ? "on" : ""}" id="master" ${linked ? "" : "disabled"} aria-label="toggle"></button></div>
  <div class="msg ${linked ? "mut" : ""}" id="mmsg">${linked ? "Takes effect on the next run (up to ~30 min). Tap to flip." : "Connect GitHub below to flip this from your phone."}</div></div>
  <h3 class="sec">Alert rules</h3>
  <div class="set">${["WATCH", "SETUP", "BUY"].map(k => `<div class="row"><div>${badge(k)} <span class="mut" style="margin-left:6px">${{ WATCH: "Heading to a key level", SETUP: "At the level, unconfirmed", BUY: "Reversal confirmed" }[k]}</span></div><button class="sw ${al.includes(k) ? "on" : ""}" data-al="${k}" ${linked ? "" : "disabled"}></button></div>`).join("")}
  <div class="row"><span>Minimum score to alert</span><input id="mins" type="number" min="0" max="100" value="${cfg.min_score ?? 40}" style="width:80px;margin:0" ${linked ? "" : "disabled"}></div></div>
  <h3 class="sec">Phone notifications (ntfy)</h3>
  <div class="set"><p>1) Install the free <b>ntfy</b> app from the App Store. 2) Subscribe to your secret topic. 3) Put the same topic in GitHub as secret <code>NTFY_TOPIC</code>.</p>
  <input type="text" id="topic" placeholder="your-secret-topic-name" value="${esc(topic)}" autocapitalize="off" autocorrect="off">
  <button class="btn sec" id="tsave">Save</button> <button class="btn" id="ttest">Send test alert</button> <a class="btn sec" style="display:inline-block" href="ntfy://ntfy.sh/${encodeURIComponent(topic)}">Open ntfy</a><div class="msg" id="tmsg"></div></div>
  <h3 class="sec">Connect GitHub (for the on/off switch)</h3>
  <div class="set"><p>Repo as <code>owner/name</code>, plus a fine-grained token limited to that repo with <b>Contents: Read and write</b>. Stored only on this phone.</p>
  <input type="text" id="repo" placeholder="owner/dipline" value="${esc(GH.repo())}" autocapitalize="off" autocorrect="off">
  <input type="password" id="tok" placeholder="github_pat_..." value="${esc(GH.tok())}">
  <button class="btn" id="gsave">Save &amp; verify</button><div class="msg" id="gmsg"></div></div>
  <div class="disc">Dipline ${S.sig ? "· data " + ago(S.sig.meta.generated_at) : ""}<br>Rules-based screening only. Not financial advice.</div>`;
}
function bindSettings() {
  const msg = (id, t, ok) => { const e = $(id); e.textContent = t; e.style.color = ok ? "var(--up)" : "var(--dn)"; };
  const flip = async (patch, btn) => { btn.disabled = true; try { await patchCfg(patch); render(); } catch (e) { msg("#mmsg", e.message, false); btn.disabled = false; } };
  const m = $("#master"); if (m) m.onclick = () => flip({ enabled: !(S.cfg?.enabled !== false) }, m);
  document.querySelectorAll("[data-al]").forEach(b => b.onclick = () => { const cur = new Set(S.cfg?.alert_on || ["WATCH", "SETUP", "BUY"]); cur.has(b.dataset.al) ? cur.delete(b.dataset.al) : cur.add(b.dataset.al); flip({ alert_on: [...cur] }, b); });
  const ms = $("#mins"); if (ms) ms.onchange = () => flip({ min_score: Math.max(0, Math.min(100, +ms.value || 0)) }, ms);
  $("#tsave").onclick = () => { LS.set("topic", $("#topic").value.trim()); msg("#tmsg", "Saved.", true); render(); };
  $("#ttest").onclick = async () => {
    const t = $("#topic").value.trim(); if (!t) return msg("#tmsg", "Enter your topic first.", false); LS.set("topic", t);
    try { const r = await fetch("https://ntfy.sh/" + encodeURIComponent(t), { method: "POST", body: "Test alert from Dipline. If you see this on your lock screen, you're set.", headers: { Title: "Dipline test", Priority: "4", Tags: "white_check_mark" } }); msg("#tmsg", r.ok ? "Sent - check your phone." : "ntfy error " + r.status, r.ok); } catch (e) { msg("#tmsg", "Could not reach ntfy.sh", false); }
  };
  $("#gsave").onclick = async () => {
    LS.set("repo", $("#repo").value.trim()); LS.set("tok", $("#tok").value.trim()); msg("#gmsg", "Checking…", true);
    try { const { cfg } = await readCfg(); S.cfg = cfg; msg("#gmsg", "Connected. You can now use the switches above.", true); setTimeout(render, 700); } catch (e) { msg("#gmsg", e.message, false); }
  };
}

/* ---------- detail sheet ---------- */
const WHY_KEYS = [["THE DROP", "DROP"], ["MARKET-WIDE", "MARKET"], ["STOCK-SPECIFIC", "CAUTION"], ["KEY LEVEL", "KEY"], ["TOUCH", "TOUCH"], ["CONFIRM", "CONFIRM"], ["CAUTION", "CAUTION"], ["PLAN", "PLAN"], ["TREND", "TREND"], ["RISK/REWARD", "KEY"]];
function whyItem(t) { const i = t.indexOf(":"), tag = i > 0 && i < 18 ? t.slice(0, i) : "", k = (WHY_KEYS.find(x => x[0] === tag) || [0, "INFO"])[1]; return `<li class="k-${k}">${tag ? `<b>${esc(tag)}</b>${esc(t.slice(i + 1))}` : esc(t)}</li>`; }
async function openSheet(t) {
  const r = S.sig?.rows.find(x => x.t === t), sh = $("#sheet"); if (!r) { sh.hidden = true; return; }
  sh.hidden = false; document.body.style.overflow = "hidden";
  const fav = S.favs.includes(t), p = r.plan, cur = r.lv;
  const lv = [...(r.lvls || [])].sort((a, b) => b.p - a.p);
  sh.innerHTML = `<div class="sh-top"><button id="back">‹ Back</button><div style="flex:1"></div><button id="fv">${fav ? "★ In my list" : "☆ Add to list"}</button></div>
  <div class="sh-h"><span class="t">${r.t}</span><span class="p">$${n2(r.p)} ${pct(r.c1)}</span><div class="n">${esc(r.n)} · ${esc(r.s)} · Mkt cap ${cap(r.mc)}</div></div>
  <div class="hero">${badge(r.st)} ${scBadge(r.sc)}${r.prov ? " <span class='mut' style='font-size:11px'>intraday — confirm at close</span>" : ""}<div style="margin-top:8px"><b>${esc(r.hl)}</b></div>${p ? `<div style="margin-top:10px">${planBox(p)}</div>` : ""}</div>
  <div class="rng">${[60, 100, 160].map(n => `<span class="chip ${S.range === n ? "on" : ""}" data-r="${n}">${n}D</span>`).join("")}</div>
  <canvas id="ch"></canvas><div class="ro" id="ro">Touch the chart to inspect candles</div>
  <h3 class="sec">What's happening</h3><ul class="why">${(r.why.length ? r.why : ["No key support nearby."]).map(whyItem).join("")}</ul>
  <h3 class="sec">Key levels (support / resistance)</h3><div class="lv">${lv.length ? lv.map(x => `<div class="${x.p === cur ? "cur" : ""}"><span>${esc(x.l)}${x.p === cur ? " ← active" : ""}</span><b>$${n2(x.p)} <span class="mut">(${n2((x.p / r.p - 1) * 100, 1)}%)</span></b></div>`).join("") : '<div class="mut">None detected.</div>'}</div>
  <h3 class="sec">Snapshot</h3><div class="snap">${[["Price", "$" + n2(r.p)], ["Change", pct(r.c1)], ["5D / 20D", pct(r.c5, 1) + " / " + pct(r.c20, 1)], ["RSI (14)", r.rsi], ["Rel Volume", n2(r.rv) + "x"], ["ATR %", n2(r.atr) + "%"], ["vs SMA50", pct(r.d50, 1)], ["vs SMA200", pct(r.d200, 1)], ["52W High", "$" + n2(r.h52)], ["52W Low", "$" + n2(r.l52)], ["From 52W High", pct(r.fh, 1)], ["Mkt Cap", cap(r.mc)]].map(([a, b]) => `<div><span>${a}</span><b>${b}</b></div>`).join("")}</div>
  <div class="disc">Educational screening only — not financial advice. Check news &amp; earnings dates before acting.</div>`;
  sh.scrollTop = 0;
  $("#back").onclick = () => { location.hash = "#" + (LS.get("last", "/")); };
  $("#fv").onclick = () => { toggleFav(t); openSheet(t); };
  sh.querySelectorAll("[data-r]").forEach(b => b.onclick = () => { S.range = +b.dataset.r; openSheet(t); });
  const ch = await ensureCharts(); drawChart(r, ch);
}
function drawChart(r, charts) {
  const cv = $("#ch"); if (!cv || !charts[r.t]) return;
  const dpr = window.devicePixelRatio || 1, W = cv.clientWidth, H = 300; cv.width = W * dpr; cv.height = H * dpr;
  const g = cv.getContext("2d"); g.scale(dpr, dpr);
  const all = charts[r.t], dates = charts._dates, n = Math.min(S.range, all.length), off = all.length - n, d = all.slice(off);
  // SMA50 over full history for the visible window
  const cl = all.map(x => x[3]), sma = cl.map((_, i) => i < 49 ? null : cl.slice(i - 49, i + 1).reduce((a, b) => a + b, 0) / 50).slice(off);
  const padR = 56, padB = 16, vh = 46, ph = H - padB - vh - 6, w = W - padR, cw = w / n;
  const lvls = (r.lvls || []).filter(x => x.p > 0), p = r.plan;
  let lo = Math.min(...d.map(x => x[2])), hi = Math.max(...d.map(x => x[1]));
  if (p) { lo = Math.min(lo, p.stop); hi = Math.max(hi, p.target); }
  lvls.forEach(x => { if (x.p > lo * 0.9 && x.p < hi * 1.1) { lo = Math.min(lo, x.p); hi = Math.max(hi, x.p); } });
  const m = (hi - lo) * 0.05; lo -= m; hi += m;
  const Y = v => 4 + (hi - v) / (hi - lo) * ph, X = i => i * cw + cw / 2;
  g.fillStyle = "#0b0f14"; g.fillRect(0, 0, W, H); g.font = "10px -apple-system,sans-serif"; g.textBaseline = "middle";
  for (let i = 0; i <= 4; i++) { const v = lo + (hi - lo) * i / 4, y = Y(v); g.strokeStyle = "#151d27"; g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); g.fillStyle = "#6b7887"; g.textAlign = "left"; g.fillText(v.toFixed(2), w + 4, y); }
  if (p) { g.fillStyle = "rgba(46,204,113,.13)"; g.fillRect(0, Y(p.entry_hi), w, Y(p.entry_lo) - Y(p.entry_hi)); }
  const line = (v, col, dash, lab) => { if (v < lo || v > hi) return; const y = Y(v); g.strokeStyle = col; g.setLineDash(dash); g.lineWidth = 1; g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); g.setLineDash([]); g.fillStyle = col; g.textAlign = "right"; if (lab) g.fillText(lab, w - 3, y - 6); };
  lvls.forEach(x => line(x.p, x.p === r.lv ? "#f5a623" : "#4aa3ff88", x.p === r.lv ? [] : [4, 4], x.p === r.lv ? "KEY " + x.p.toFixed(2) : ""));
  if (p) { line(p.stop, "#ef5350", [2, 3], "STOP"); line(p.target, "#2ecc71", [2, 3], "TARGET"); }
  // volume
  const mv = Math.max(...d.map(x => x[4])); d.forEach((x, i) => { g.fillStyle = x[3] >= x[0] ? "rgba(46,204,113,.35)" : "rgba(239,83,80,.35)"; const bh = x[4] / mv * vh; g.fillRect(i * cw + 1, H - padB - bh, Math.max(1, cw - 2), bh); });
  // candles
  d.forEach((x, i) => { const [o, h, l, c] = x, up = c >= o, col = up ? "#2ecc71" : "#ef5350", cx = X(i); g.strokeStyle = col; g.fillStyle = col; g.lineWidth = 1; g.beginPath(); g.moveTo(cx, Y(h)); g.lineTo(cx, Y(l)); g.stroke(); const t = Y(Math.max(o, c)), b = Y(Math.min(o, c)); g.fillRect(cx - Math.max(1, cw * 0.35), t, Math.max(2, cw * 0.7), Math.max(1, b - t)); });
  g.strokeStyle = "#f5a623aa"; g.lineWidth = 1.3; g.beginPath(); let st = false; sma.forEach((v, i) => { if (v == null) return; st ? g.lineTo(X(i), Y(v)) : (g.moveTo(X(i), Y(v)), st = true); }); g.stroke();
  const ro = $("#ro"); const show = e => { const rc = cv.getBoundingClientRect(), x = (e.touches ? e.touches[0].clientX : e.clientX) - rc.left, i = Math.max(0, Math.min(n - 1, Math.floor(x / cw))), k = d[i]; ro.innerHTML = `${dates[off + i]} · O ${k[0]} H ${k[1]} L ${k[2]} C <b style="color:var(--tx)">${k[3]}</b> · Vol ${(k[4] / 1e6).toFixed(1)}M`; };
  cv.onmousemove = show; cv.ontouchstart = cv.ontouchmove = show;
  ro.innerHTML = `<span style="color:#f5a623">━</span> SMA50 · <span style="color:#4aa3ff">┅</span> support levels · green band = entry zone`;
}

/* ---------- router ---------- */
function render() {
  renderHeader();
  const route = location.hash.replace(/^#/, "") || "/", v = $("#view");
  const tab = route.startsWith("/map") ? "map" : route.startsWith("/signals") ? "signals" : route.startsWith("/alerts") ? "alerts" : route.startsWith("/settings") ? "settings" : "screener";
  document.querySelectorAll("#tabs a").forEach(a => a.classList.toggle("on", a.dataset.t === tab));
  if (!route.startsWith("/t/")) { LS.set("last", route); $("#sheet").hidden = true; document.body.style.overflow = ""; }
  if (S.err && !S.sig) { v.innerHTML = `<div class="empty">No scan data yet.<br><br>The first scan runs right after setup (or tap <b>Run workflow</b> in GitHub Actions).<br><span class="mut" style="font-size:11px">${esc(S.err)}</span></div>`; return; }
  if (!S.sig) { v.innerHTML = '<div class="loader">Loading…</div>'; return; }
  if (tab === "screener") { v.innerHTML = viewScreener(); bindScreener(); }
  else if (tab === "map") { v.innerHTML = viewMap(); drawMap(); v.querySelectorAll("[data-mm]").forEach(b => b.onclick = () => { S.mapMode = b.dataset.mm; render(); }); }
  else if (tab === "signals") { v.innerHTML = viewSignals(); }
  else if (tab === "alerts") { v.innerHTML = viewAlerts(); }
  else { v.innerHTML = viewSettings(); bindSettings(); }
  v.querySelectorAll(".card[data-t]").forEach(c => c.onclick = () => location.hash = "#/t/" + c.dataset.t);
  if (route.startsWith("/t/")) openSheet(decodeURIComponent(route.slice(3)));
}
window.addEventListener("hashchange", render);
window.addEventListener("resize", () => { if (location.hash === "#/map") drawMap(); });
document.addEventListener("visibilitychange", () => { if (!document.hidden) loadAll(); });
setInterval(() => { if (!document.hidden) loadAll(); }, 120000);
if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(() => {});
render(); loadAll(true);
