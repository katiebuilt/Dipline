# Dipline - Top 100 US buy-the-dip scanner for iPhone

Finviz-style screener, heat map and signal list that runs on your iPhone as a home-screen app,
plus a cloud scanner that watches the 100 largest US companies for you and pings your phone.

## How it finds a buy
1. **Key levels** per stock: 200/50-day MAs, swing lows, 52-week low, Fibonacci 38.2/50/61.8, flipped resistance.
   Nearby levels are clustered; confluence = stronger level (needs an "anchor" such as a MA, Fib or 2+ swing lows).
2. **States**
   - WATCH - sliding toward a key level (below its 20-day high, within ~2.5-5% of the level): plan the entry.
   - SETUP - price touched the level after a real drop: get ready, no reversal yet.
   - BUY - touched + at least 2 of 4 confirmations (reversal candle, RSI turning up from oversold, volume >= 1.3x on an up-close, close above yesterday's high).
3. **"What's happening"** on every stock: how far it dropped, market-wide vs stock-specific, which level, which confirmations, trend, stop/target/R:R.
4. Alerts fire only on **upgrades** (none > WATCH > SETUP > BUY), with a 24h cooldown per stock/state, so no spam.

## Setup (about 10 minutes, all free)
1. Create a **public** GitHub repo (e.g. `dipline`) and upload this folder (`scanner/`, `docs/`, `.github/`, `requirements.txt`).
2. Repo **Settings > Pages > Source: GitHub Actions**.
3. On your iPhone install **ntfy** (App Store, free). Subscribe to a long random topic, e.g. `dipline-k8f3x9q2m7`.
4. Repo **Settings > Secrets and variables > Actions**:
   - Secret `NTFY_TOPIC` = your topic
   - Variable `APP_URL` = `https://<you>.github.io/<repo>` (tapping an alert opens that stock)
5. **Actions tab > Dipline scan > Run workflow** (tick "force"). When it finishes, open `https://<you>.github.io/<repo>` in **Safari > Share > Add to Home Screen**.
6. In the app: **Settings > Send test alert** to confirm notifications arrive.
7. *On/off from your phone:* GitHub > Settings > Developer settings > Fine-grained tokens > new token, only this repo, **Contents: Read and write**. Paste repo + token in the app's Settings. The big switch edits `docs/config.json` (`"enabled": true/false`). You can also edit that file on github.com.

## Running
- Scans every 30 min, 9:30-16:00 ET weekdays (+ one after the close). Switch off = it does nothing.
- Data: Yahoo Finance via `yfinance` (free, delayed ~15 min, not guaranteed). Results live on a `data` branch so your main history stays small.
- Try locally with fake data: `pip install -r requirements.txt && python scanner/scan.py --demo && python -m http.server -d docs 8000`.

## Customize
- `scanner/universe.py` - the stock list. Add rows / change `TOP_N` to expand (e.g. S&P 500 later).
- `scanner/engine.py` - thresholds (`MIN_STRENGTH`, WATCH distance, confirmations, score weights).
- `docs/config.json` - which states alert, minimum score, max alerts per run, cooldown.

## Limits
Rules-based screening, not advice, and no strategy wins every time. No earnings-date filter yet: check news/earnings before buying.
The Top 100 list is hand-maintained (approximate by market cap) - refresh it occasionally.
