"""Push notifications to your iPhone through ntfy (free iOS app + ntfy.sh)."""
import os, urllib.request

PRIO = {"BUY": "5", "SETUP": "4", "WATCH": "3"}
TAGS = {"BUY": "white_check_mark,chart_with_upwards_trend", "SETUP": "eyes", "WATCH": "mag"}
LABEL = {"BUY": "BUY ZONE", "SETUP": "AT KEY LEVEL", "WATCH": "WATCH"}


def send(title, body, state, click=None, topic=None, server=None):
    topic = topic or os.environ.get("NTFY_TOPIC")
    if not topic:
        print("[notify] NTFY_TOPIC not set - would send:", title, "|", body)
        return False
    server = (server or os.environ.get("NTFY_SERVER") or "https://ntfy.sh").rstrip("/")
    req = urllib.request.Request(f"{server}/{topic}", data=body.encode("utf-8"), method="POST")
    req.add_header("Title", title.encode("ascii", "ignore").decode())
    req.add_header("Priority", PRIO.get(state, "3"))
    req.add_header("Tags", TAGS.get(state, "bell"))
    if click: req.add_header("Click", click)
    try:
        urllib.request.urlopen(req, timeout=15).read()
        return True
    except Exception as e:
        print("[notify] failed:", e)
        return False


def alert_text(r):
    """r is a compact scan row."""
    p = r["plan"] or {}
    title = f"{LABEL[r['st']]}: {r['t']} ${r['p']:,.2f} (score {r['sc']})"
    body = (f"{r['hl']}\n"
            f"Entry ${p.get('entry_lo')}-{p.get('entry_hi')} | Stop ${p.get('stop')} | Target ${p.get('target')} (R:R {p.get('rr')})\n"
            "Not financial advice.")
    return title, body
