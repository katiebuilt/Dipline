"""Market data: Yahoo Finance via yfinance (live) or a synthetic generator (demo)."""
from __future__ import annotations
import json, os, time, datetime as dt
import numpy as np
import pandas as pd

COLS = ["Open", "High", "Low", "Close", "Volume"]
INDEXES = {"SPY": "S&P 500", "QQQ": "Nasdaq 100", "DIA": "Dow 30", "IWM": "Russell 2000", "^VIX": "VIX"}


def fetch_yf(tickers, period="2y"):
    import yfinance as yf
    out = {}
    raw = yf.download(list(tickers), period=period, interval="1d", group_by="ticker",
                      auto_adjust=True, threads=True, progress=False)
    for t in tickers:
        try:
            df = raw[t][COLS].dropna()
            if len(df) > 50: out[t] = df
        except Exception:
            pass
    for t in [t for t in tickers if t not in out]:  # retry stragglers one by one
        try:
            time.sleep(0.5)
            df = yf.Ticker(t).history(period=period, interval="1d", auto_adjust=True)[COLS].dropna()
            if len(df) > 50: out[t] = df
        except Exception:
            pass
    return out


def fetch_caps(tickers, cache_path, max_age_days=7):
    """Market caps (for ranking + heatmap sizes). Cached on disk, refreshed weekly."""
    try:
        cached = json.load(open(cache_path))
        age = (dt.date.today() - dt.date.fromisoformat(cached["date"])).days
        if age < max_age_days and all(t in cached["caps"] for t in tickers):
            return cached["caps"]
    except Exception:
        cached = {"caps": {}}
    import yfinance as yf
    caps = dict(cached.get("caps", {}))
    for t in tickers:
        try:
            fi = yf.Ticker(t).fast_info
            m = fi["marketCap"] if "marketCap" in fi else fi.market_cap
            if m: caps[t] = float(m)
        except Exception:
            pass
    json.dump({"date": dt.date.today().isoformat(), "caps": caps}, open(cache_path, "w"))
    return caps


# ---------------- demo (synthetic) data: for testing the pipeline offline ----------------
def demo_frames(universe, seed=7):
    from engine import build_levels
    rng = np.random.default_rng(seed)
    end = pd.Timestamp.today().normalize()
    idx = pd.bdate_range(end=end, periods=320)
    frames = {}
    tickers = [u[0] for u in universe] + list(INDEXES)
    scen = {}
    kinds = ["watch"] * 10 + ["setup"] * 5 + ["buy"] * 5
    pick = rng.permutation(len(universe))[:len(kinds)]
    for k, i in zip(kinds, pick): scen[universe[i][0]] = k
    for n, t in enumerate(tickers):
        base = float(rng.uniform(40, 600)) if not t.startswith("^") else 17.0
        vol = 0.016 if not t.startswith("^") else 0.05
        r = rng.normal(0.0005, vol, len(idx))
        close = base * np.exp(np.cumsum(r))
        openp = np.r_[close[0], close[:-1]] * (1 + rng.normal(0, 0.003, len(idx)))
        hi = np.maximum(openp, close) * (1 + np.abs(rng.normal(0, 0.007, len(idx))))
        lo = np.minimum(openp, close) * (1 - np.abs(rng.normal(0, 0.007, len(idx))))
        v = rng.uniform(0.7, 1.3, len(idx)) * rng.uniform(5e6, 6e7)
        df = pd.DataFrame({"Open": openp, "High": hi, "Low": lo, "Close": close, "Volume": v}, index=idx)
        k = scen.get(t)
        if k:
            df = _craft(df, k, rng, build_levels)
        frames[t] = df
    return frames


def _craft(df, kind, rng, build_levels):
    head = df.iloc[:-12]
    c = head.Close
    s50, s200 = c.rolling(50).mean().iloc[-1], c.rolling(200).mean().iloc[-1]
    # a gentle uptrend into the last 12 bars so the dip is a pullback
    lv = [x for x in build_levels(head, s50, s200, 0.012) if x["strength"] >= 1.8 and x["price"] < c.iloc[-1] * 0.97]
    if not lv: return df
    L = max(lv, key=lambda x: x["price"])["price"]
    start = float(c.iloc[-1]); n = 12
    end_close = {"watch": L * 1.018, "setup": L * 1.004, "buy": L * 1.022}[kind]
    path = np.linspace(start, L * 1.004 if kind == "buy" else end_close, n)
    if kind == "buy": path[-1] = end_close
    path[:-1] *= 1 + rng.normal(0, 0.003, n - 1)
    rows = []
    prev = start
    for i, cl in enumerate(path):
        op = prev * (1 + rng.normal(0, 0.002))
        hi_, lo_ = max(op, cl) * 1.004, min(op, cl) * 0.996
        vol = float(df.Volume.iloc[-20:].mean()) * rng.uniform(0.8, 1.2)
        if kind == "buy" and i == n - 2:  # the touch bar
            lo_ = L * 0.996; cl = L * 1.003; hi_ = L * 1.009; op = L * 1.012
        if kind == "buy" and i == n - 1:  # hammer reversal on volume
            op = L * 1.002; lo_ = L * 0.994; hi_ = cl * 1.003; vol *= 2.1
            path[i] = cl
        if kind == "setup" and i == n - 1:
            lo_ = L * 0.997; op = cl * 1.004
        rows.append((op, hi_, lo_, cl, vol)); prev = cl
    tail = pd.DataFrame(rows, index=df.index[-12:], columns=["Open", "High", "Low", "Close", "Volume"])
    return pd.concat([head, tail])
