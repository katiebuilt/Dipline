"""Dipline analysis engine: key levels, buy-state machine, scoring and plain-English 'why'.

Everything here is pure (DataFrame in -> dict out) so it is easy to test.

States
  WATCH  price is sliding toward a strong support level (plan a buy)
  SETUP  price is AT the level, reversal not confirmed yet (get ready)
  BUY    price tagged the level AND buyers confirmed (>=2 confirmations)
  NONE   nothing actionable
"""
from __future__ import annotations
import numpy as np
import pandas as pd

# weights for level sources -> a cluster needs MIN_STRENGTH to count as a "key" level
W = {"sma200": 1.8, "sma50": 1.2, "swing_low": 1.0, "flip_high": 0.4, "low52": 1.5,
     "fib618": 1.0, "fib500": 1.0, "fib382": 0.8}
MIN_STRENGTH = 2.0
NAMES = {"sma200": "200-day MA", "sma50": "50-day MA", "swing_low": "swing low", "flip_high": "old resistance",
         "low52": "52-week low", "fib618": "61.8% Fib", "fib500": "50% Fib", "fib382": "38.2% Fib"}


# ---------- indicators ----------
def rsi(close: pd.Series, n=14) -> pd.Series:
    d = close.diff()
    up, dn = d.clip(lower=0), -d.clip(upper=0)
    ru, rd = up.ewm(alpha=1 / n, adjust=False).mean(), dn.ewm(alpha=1 / n, adjust=False).mean()
    return 100 - 100 / (1 + ru / rd.replace(0, np.nan))


def atr(df: pd.DataFrame, n=14) -> pd.Series:
    pc = df.Close.shift()
    tr = pd.concat([df.High - df.Low, (df.High - pc).abs(), (df.Low - pc).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False).mean()


def pivots(series: pd.Series, w=4, kind="low"):
    v = series.values
    out = []
    for i in range(w, len(v) - w):
        win = v[i - w:i + w + 1]
        if (kind == "low" and v[i] == win.min()) or (kind == "high" and v[i] == win.max()):
            out.append((i, float(v[i])))
    return out


# ---------- levels ----------
def build_levels(df: pd.DataFrame, sma50: float, sma200: float, tol: float):
    price = float(df.Close.iloc[-1])
    look = df.iloc[-252:]
    raw = []
    for i, p in pivots(look.Low, 4, "low"):
        raw.append((p, "swing_low"))
    for i, p in pivots(look.High, 4, "high"):
        if p < price:
            raw.append((p, "flip_high"))
    if not np.isnan(sma200): raw.append((sma200, "sma200"))
    if not np.isnan(sma50): raw.append((sma50, "sma50"))
    raw.append((float(look.Low.min()), "low52"))
    # Fibonacci retracement of the most recent major up-swing
    hi_i = int(look.High.values.argmax())
    if hi_i > 20:
        hi = float(look.High.values[hi_i])
        lo = float(look.Low.values[:hi_i].min())
        if hi - lo > 0.10 * hi:
            for r, k in ((0.382, "fib382"), (0.5, "fib500"), (0.618, "fib618")):
                raw.append((hi - r * (hi - lo), k))
    raw.sort()
    clusters, cur = [], []
    for p, k in raw:
        if cur and p <= np.mean([c[0] for c in cur]) * (1 + tol):
            cur.append((p, k))
        else:
            if cur: clusters.append(cur)
            cur = [(p, k)]
    if cur: clusters.append(cur)
    out = []
    for c in clusters:
        kinds = {}
        for _, k in c: kinds[k] = kinds.get(k, 0) + 1
        strength = sum(W[k] * min(n_, 3) for k, n_ in kinds.items())  # repeats count, but capped
        order = sorted(kinds, key=lambda k: -W[k] * kinds[k])
        label = " + ".join((f"{kinds[k]}x " if kinds[k] > 1 else "") + NAMES[k] for k in order[:3])
        wp = sum(p * W[k] for p, k in c) / sum(W[k] for _, k in c)
        out.append({"price": round(wp, 2), "strength": round(strength, 1), "label": label,
                    "touches": kinds.get("swing_low", 0),
                    "anchor": any(k in kinds for k in ("sma200", "sma50", "low52", "fib618", "fib500", "fib382")) or kinds.get("swing_low", 0) >= 2})
    return out


# ---------- main analysis ----------
def analyze(df: pd.DataFrame, spy: dict | None = None, progress: float = 1.0, provisional: bool = False) -> dict | None:
    """df: daily OHLCV (>=220 rows). spy: {'chg1':..,'chg5':..}. progress: fraction of today's session elapsed."""
    if df is None or len(df) < 220:
        return None
    df = df.copy()
    c, h, l, o, v = df.Close, df.High, df.Low, df.Open, df.Volume
    price = float(c.iloc[-1]); prev = float(c.iloc[-2])
    s50 = float(c.rolling(50).mean().iloc[-1]); s200 = float(c.rolling(200).mean().iloc[-1])
    rs = rsi(c); r_now = float(rs.iloc[-1]); r_prev = float(rs.iloc[-2]); r_min4 = float(rs.iloc[-4:].min())
    a = float(atr(df).iloc[-1]); atr_pct = a / price * 100
    avgv = float(v.iloc[-21:-1].mean()) or 1.0
    relvol = float(v.iloc[-1]) / (avgv * max(progress, 0.25))
    hi52, lo52 = float(h.iloc[-252:].max()), float(l.iloc[-252:].min())
    hi20 = float(h.iloc[-20:].max())
    ret = lambda n: (price / float(c.iloc[-1 - n]) - 1) * 100
    chg1, chg5, chg20 = ret(1), ret(5), ret(20)
    pull = (price / hi20 - 1) * 100  # negative = below 20d high

    tol = float(np.clip(a / price, 0.008, 0.02))
    levels = [x for x in build_levels(df, s50, s200, tol) if abs(x["price"] / price - 1) <= 0.25]
    key = [x for x in levels if x["strength"] >= MIN_STRENGTH and x["anchor"]]
    sup = [x for x in key if x["price"] <= price * 1.01]
    res = [x for x in key if x["price"] > price * 1.01]
    lvl = max(sup, key=lambda x: x["price"]) if sup else None
    target = min(res, key=lambda x: x["price"])["price"] if res else hi52
    if target <= price * 1.01: target = round(price * 1.08, 2)

    base = {"price": price, "chg1": chg1, "chg5": chg5, "chg20": chg20, "rsi": r_now, "atr_pct": atr_pct,
            "relvol": relvol, "sma50": s50, "sma200": s200, "hi52": hi52, "lo52": lo52,
            "from_hi52": (price / hi52 - 1) * 100, "levels": key, "state": "NONE", "score": 0,
            "level": None, "dist": None, "why": [], "headline": "No key support nearby.", "plan": None,
            "provisional": provisional}
    if not lvl:
        base["score"] = int(max(0, min(25, 25 - abs(base["from_hi52"]) / 2)))
        return base

    L = lvl["price"]
    dist = (price / L - 1) * 100
    tol_abs = max(0.5 * a, 0.004 * L)
    low3 = float(l.iloc[-3:].min())
    touched = low3 <= L + tol_abs and price >= L - 0.75 * a

    # confirmations on latest bar
    O, H, Lw, C = float(o.iloc[-1]), float(h.iloc[-1]), float(l.iloc[-1]), price
    rng = max(H - Lw, 1e-9)
    ph = float(h.iloc[-2])
    conf = {
        "hammer": C > O and (C - Lw) / rng >= 0.6 and ((min(O, C) - Lw) / rng >= 0.3 or C > ph),
        "rsi_turn": r_min4 <= 40 and r_now > r_prev,
        "volume": relvol >= 1.3 and C > (H + Lw) / 2,
        "reclaim": C > ph,
    }
    nconf = sum(conf.values())
    context_drop = pull <= -5 or r_min4 <= 38
    # a real "drop into the level": recent 10-day high must sit well above it
    hi10 = float(h.iloc[-10:].max())
    came_down = hi10 >= L * (1 + max(0.03, 2 * atr_pct / 100))
    heading_in = came_down and (chg5 < 0 or r_now < 50) and pull <= -2

    if touched and came_down and nconf >= 2 and (conf["hammer"] or conf["reclaim"]) and context_drop:
        state = "BUY"
    elif touched and came_down and context_drop:
        state = "SETUP"
    elif 0 < dist <= min(5.0, max(2.5, 1.5 * atr_pct)) and heading_in:
        state = "WATCH"
    else:
        state = "NONE"

    # plan
    stop = L - 1.0 * a
    entry_hi = L + 0.5 * a
    entry_mid = min(price, entry_hi) if state in ("BUY", "SETUP") else (L + entry_hi) / 2
    risk = max(entry_mid - stop, 1e-9)
    rr = (target - entry_mid) / risk
    plan = {"entry_lo": round(L, 2), "entry_hi": round(entry_hi, 2), "stop": round(stop, 2),
            "target": round(target, 2), "rr": round(rr, 1)}

    # score 0-100
    score = max(0.0, 1 - dist / 3.0) * 30 if dist > 0 else 30
    score += min(lvl["strength"], 4) / 4 * 20
    score += nconf * 7.5
    score += (6 if price > s200 else 0) + (4 if s50 > s200 else 0)
    score += min(max(rr, 0) / 3, 1) * 10
    if state == "NONE": score = min(score, 39)
    elif state == "WATCH": score = min(score, 74)
    elif state == "SETUP": score = min(score, 79)

    # -------- plain-English 'why' --------
    why = []
    drop_from = f"{abs(pull):.1f}% below its 20-day high (${hi20:,.2f})"
    why.append(f"THE DROP: {drop_from}; {chg5:+.1f}% over 5 days, {chg20:+.1f}% over 20 days.")
    if spy:
        rel5 = chg5 - spy.get("chg5", 0)
        if spy.get("chg5", 0) <= -2 and rel5 > -2.5:
            why.append(f"MARKET-WIDE: S&P 500 is {spy['chg5']:+.1f}% over 5 days, so most of this is the market, not the company.")
        elif rel5 <= -3:
            why.append(f"STOCK-SPECIFIC: lagging the S&P 500 by {abs(rel5):.1f} pts over 5 days. Check news/earnings before buying.")
        else:
            why.append(f"In line with the market (S&P 500 {spy.get('chg5', 0):+.1f}% over 5 days).")
    n_t = lvl["touches"]
    why.append(f"KEY LEVEL: ${L:,.2f} = {lvl['label']} (strength {lvl['strength']}"
               f"{', tested ' + str(n_t) + ' times before' if n_t > 1 else ''}). Price is {abs(dist):.1f}% {'above' if dist >= 0 else 'below'} it.")
    if state in ("BUY", "SETUP"):
        why.append(f"TOUCH: the last 3 days' low (${low3:,.2f}) reached the level.")
    if conf["hammer"]: why.append("CONFIRM: bullish reversal candle (long lower wick / strong close) - sellers rejected.")
    if conf["reclaim"]: why.append(f"CONFIRM: closed above yesterday's high (${ph:,.2f}) - short-term trend turned up.")
    if conf["rsi_turn"]: why.append(f"CONFIRM: RSI dipped to {r_min4:.0f} (oversold zone) and is turning up ({r_now:.0f}).")
    if conf["volume"]: why.append(f"CONFIRM: volume {relvol:.1f}x average on an up-close - buyers stepping in.")
    elif relvol >= 1.5 and chg1 < 0: why.append(f"CAUTION: heavy selling volume ({relvol:.1f}x average) - wait for it to dry up.")
    if state == "WATCH":
        why.append(f"PLAN: not at the level yet. Look for entries ${plan['entry_lo']:,.2f}-${plan['entry_hi']:,.2f} if it holds with a reversal.")
    why.append(("TREND: above" if price > s200 else "CAUTION: below") + f" the 200-day MA (${s200:,.2f})"
               + (" - buying a dip in an uptrend." if price > s200 else " - dip-buying against the long-term trend is riskier."))
    why.append(f"RISK/REWARD: stop ${plan['stop']:,.2f} (1 ATR under level), target ${plan['target']:,.2f}, R:R {plan['rr']}:1.")

    head = {
        "BUY": f"Reversal at {lvl['label']} (${L:,.2f}). {nconf} buyer confirmations" + (" - intraday, confirm at close." if provisional else "."),
        "SETUP": f"At {lvl['label']} (${L:,.2f}). Waiting for a reversal signal.",
        "WATCH": f"Heading toward {lvl['label']} (${L:,.2f}), {dist:.1f}% away. Plan an entry.",
        "NONE": f"Nearest support ${L:,.2f} ({lvl['label']}) is {dist:.1f}% below.",
    }[state]

    base.update({"state": state, "score": int(round(min(score, 100))), "level": lvl, "dist": dist,
                 "why": why, "headline": head, "plan": plan, "conf": [k for k, v_ in conf.items() if v_]})
    return base
