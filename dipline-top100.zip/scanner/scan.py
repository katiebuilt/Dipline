"""Dipline scanner. Run on a schedule (GitHub Actions) or by hand.

  python scanner/scan.py            # live data, respects config.json 'enabled' + market hours
  python scanner/scan.py --force    # ignore on/off switch and market hours
  python scanner/scan.py --demo     # synthetic data, no network, no notifications
"""
import argparse, json, os, sys, datetime as dt
from zoneinfo import ZoneInfo
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import data, engine, notify
from universe import UNIVERSE

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DOCS = os.path.join(ROOT, "docs"); DATA = os.path.join(DOCS, "data")
ET = ZoneInfo("America/New_York")
RANK = {"NONE": 0, "WATCH": 1, "SETUP": 2, "BUY": 3}
DEFAULT_CFG = {"enabled": True, "alert_on": ["WATCH", "SETUP", "BUY"], "min_score": 40,
               "max_alerts_per_run": 8, "cooldown_hours": 24, "market_hours_only": True}


def load(path, default):
    try:
        return json.load(open(path))
    except Exception:
        return default


def save(path, obj):
    with open(path, "w") as f:
        json.dump(obj, f, separators=(",", ":"))


def r2(x, n=2):
    return None if x is None or (isinstance(x, float) and np.isnan(x)) else round(float(x), n)


def market_status(now):
    mins = now.hour * 60 + now.minute
    open_ = now.weekday() < 5 and 9 * 60 + 30 <= mins < 16 * 60
    grace = now.weekday() < 5 and 16 * 60 <= mins < 16 * 60 + 45  # one last scan after the close
    return open_, grace, max(0.0, min(1.0, (mins - 570) / 390))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--demo", action="store_true"); ap.add_argument("--force", action="store_true")
    ap.add_argument("--no-notify", action="store_true")
    a = ap.parse_args()
    os.makedirs(DATA, exist_ok=True)
    cfg = {**DEFAULT_CFG, **load(os.path.join(DOCS, "config.json"), {})}
    now = dt.datetime.now(ET)
    is_open, grace, prog = market_status(now)

    if not cfg["enabled"] and not (a.force or a.demo):
        print("Dipline is switched OFF in config.json - nothing to do."); return
    if cfg["market_hours_only"] and not (is_open or grace or a.force or a.demo):
        print("Market closed - skipping scan."); return

    tickers = [u[0] for u in UNIVERSE]
    if a.demo:
        frames = data.demo_frames(UNIVERSE)
        caps = {t: float(np.random.default_rng(i).uniform(2e11, 4e12) / (1 + i * 0.12)) for i, t in enumerate(tickers)}
    else:
        frames = data.fetch_yf(tickers + list(data.INDEXES))
        caps = data.fetch_caps(tickers, os.path.join(DATA, "caps.json"))
    if len([t for t in tickers if t in frames]) < 50:
        print("Too little data came back - aborting without overwriting."); sys.exit(1)

    # market context
    market, spy = [], {}
    for sym, name in data.INDEXES.items():
        df = frames.get(sym)
        if df is None or len(df) < 7: continue
        c = df.Close
        m = {"sym": sym.replace("^", ""), "name": name, "price": r2(c.iloc[-1]),
             "chg1": r2((c.iloc[-1] / c.iloc[-2] - 1) * 100), "chg5": r2((c.iloc[-1] / c.iloc[-6] - 1) * 100)}
        market.append(m)
        if sym == "SPY": spy = {"chg1": m["chg1"], "chg5": m["chg5"]}

    rows, charts = [], {}
    for i, (t, name, sector) in enumerate(UNIVERSE):
        df = frames.get(t)
        if df is None: continue
        live = (not a.demo) and is_open and df.index[-1].date() == now.date()
        res = engine.analyze(df, spy, progress=prog if live else 1.0, provisional=live)
        if not res: continue
        lv = res["level"]
        rows.append({
            "t": t, "n": name, "s": sector, "mc": caps.get(t), "p": r2(res["price"]), "c1": r2(res["chg1"]),
            "c5": r2(res["chg5"]), "c20": r2(res["chg20"]), "rv": r2(res["relvol"]), "rsi": r2(res["rsi"], 0),
            "fh": r2(res["from_hi52"], 1), "d200": r2((res["price"] / res["sma200"] - 1) * 100, 1),
            "h52": r2(res["hi52"]), "l52": r2(res["lo52"]), "atr": r2(res["atr_pct"]),
            "d50": r2((res["price"] / res["sma50"] - 1) * 100, 1), "st": res["state"], "sc": res["score"], "lv": lv["price"] if lv else None,
            "ld": r2(res["dist"], 1) if res["dist"] is not None else None, "ll": lv["label"] if lv else None,
            "ls": lv["strength"] if lv else None, "hl": res["headline"], "why": res["why"], "plan": res["plan"],
            "lvls": [{"p": x["price"], "l": x["label"], "s": x["strength"]} for x in res["levels"]],
            "conf": res.get("conf", []), "prov": res["provisional"],
            "sp": [r2(x) for x in df.Close.iloc[-40:]],
        })
        d = df.iloc[-160:]
        charts[t] = [[r2(x.Open), r2(x.High), r2(x.Low), r2(x.Close), int(x.Volume)] for x in d.itertuples()]
        charts["_dates"] = [x.strftime("%Y-%m-%d") for x in d.index]
    rows.sort(key=lambda r: -(r["mc"] or 0))
    for i, r in enumerate(rows, 1): r["no"] = i

    # ---- alerts (only on upgrades, with cooldown) ----
    state = load(os.path.join(DATA, "state.json"), {})
    log = load(os.path.join(DATA, "alerts.json"), [])
    ts = int(now.timestamp()); fired = []; first_run = not state
    for r in sorted(rows, key=lambda r: -r["sc"]):
        s = state.setdefault(r["t"], {"state": "NONE", "alerts": {}})
        old, new = s["state"], r["st"]
        if (RANK[new] > RANK[old] and new in cfg["alert_on"] and r["sc"] >= cfg["min_score"]
                and ts - s["alerts"].get(new, 0) > cfg["cooldown_hours"] * 3600):
            fired.append(r); s["alerts"][new] = ts
        s["state"] = new
    fired.sort(key=lambda r: (-RANK[r["st"]], -r["sc"]))
    app = os.environ.get("APP_URL", "").rstrip("/")
    if first_run and fired and not (a.demo or a.no_notify):  # don't blast 50 pings on day one
        notify.send("Dipline is live", f"Scanning {len(rows)} stocks. Right now: " + ", ".join(
            f"{k} {v}" for k, v in {k: sum(1 for r in rows if r['st'] == k) for k in ('BUY', 'SETUP', 'WATCH')}.items())
            + ". You'll be pinged on new signals from here.", "WATCH", click=app or None)
        for r in fired: log.insert(0, {"ts": ts, "t": r["t"], "st": r["st"], "sc": r["sc"], "p": r["p"], "hl": r["hl"],
                                      "title": f"{r['st']}: {r['t']} (initial scan)", "demo": a.demo})
        fired = []
    sent = 0
    for r in fired[:cfg["max_alerts_per_run"]]:
        title, body = notify.alert_text(r)
        if not (a.demo or a.no_notify):
            notify.send(title, body, r["st"], click=f"{app}/#/t/{r['t']}" if app else None); sent += 1
        log.insert(0, {"ts": ts, "t": r["t"], "st": r["st"], "sc": r["sc"], "p": r["p"], "hl": r["hl"],
                       "title": title, "demo": a.demo})
    extra = fired[cfg["max_alerts_per_run"]:]
    if extra and not (a.demo or a.no_notify):
        notify.send(f"{len(extra)} more signals", ", ".join(f"{r['t']} ({r['st']})" for r in extra), "WATCH",
                    click=app or None)
    log = log[:150]

    counts = {k: sum(1 for r in rows if r["st"] == k) for k in ("BUY", "SETUP", "WATCH")}
    meta = {"generated_at": ts, "demo": a.demo, "market_open": is_open, "count": len(rows), "counts": counts,
            "alerts_sent": sent, "version": 1}
    save(os.path.join(DATA, "signals.json"), {"meta": meta, "market": market, "rows": rows})
    save(os.path.join(DATA, "charts.json"), charts)
    save(os.path.join(DATA, "alerts.json"), log)
    save(os.path.join(DATA, "state.json"), state)
    print(f"Scanned {len(rows)} stocks | BUY {counts['BUY']} SETUP {counts['SETUP']} WATCH {counts['WATCH']} | alerts: {len(fired)}")


if __name__ == "__main__":
    main()
